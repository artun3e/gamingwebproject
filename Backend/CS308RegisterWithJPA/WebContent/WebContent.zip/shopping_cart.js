
function changeVal(el) {
  var qt = parseFloat(el.parent().children(".qt").html());
  var price = parseFloat(el.parent().children(".price").html());
  var eq = Math.round(price * qt * 100) / 100;
  
  el.parent().children(".full-price").html( eq + "€" );
  
  changeTotal();			
}

function changeTotal() {
  
  var price = 0;
  
  $(".full-price").each(function(index){
    price += parseFloat($(".full-price").eq(index).html());
  });
  
  price = Math.round(price * 100) / 100;
  var tax = Math.round(price * 0.05 * 100) / 100
  var shipping = parseFloat($(".shipping span").html());
  var fullPrice = Math.round((price + tax + shipping) *100) / 100;
  
  if(price == 0) {
    fullPrice = 0;
  }
  
  $(".subtotal span").html(price);
  $(".tax span").html(tax);
  $(".total span").html(fullPrice);
}

$(document).ready(function(){
  
  $(".remove").click(function(){
    var el = $(this);
    el.parent().parent().addClass("removed");
    window.setTimeout(
      function(){
        el.parent().parent().slideUp('fast', function() { 
          el.parent().parent().remove(); 
          if($(".product").length == 0) {
            if(check) {
              $("#cart").html("<h1>The shop does not function, yet!</h1>");
            } else {
              $("#cart").html("<h1>No products!</h1>");
            }
          }
          changeTotal(); 
        });
      }, 200);
  });
  
  $(".qt-plus").click(function(){
    $(this).parent().children(".qt").html(parseInt($(this).parent().children(".qt").html()) + 1);
    
    $(this).parent().children(".full-price").addClass("added");
    
    var el = $(this);
    window.setTimeout(function(){el.parent().children(".full-price").removeClass("added"); changeVal(el);}, 150);
  });
  
  $(".qt-minus").click(function(){
    
    child = $(this).parent().children(".qt");
    
    if(parseInt(child.html()) > 1) {
      child.html(parseInt(child.html()) - 1);
    }
    
    $(this).parent().children(".full-price").addClass("minused");
    
    var el = $(this);
    window.setTimeout(function(){el.parent().children(".full-price").removeClass("minused"); changeVal(el);}, 150);
  });
  
  window.setTimeout(function(){$(".is-open").removeClass("is-open")}, 1200);
  
  $(".btn_check").click(function(){
    //check = true;
    //$(".remove").click();
    //var check = false;
    //var checkoutButton = document.getElementsByClassName('btn_check')
    var cartItemContainer = document.getElementsByClassName('products')[0]
    var cartRows = cartItemContainer.getElementsByClassName('product')
    var user_name_elemnent = document.getElementsByClassName('user_mail')[0]
    var user_name = user_name_elemnent.innerText
    //if(cartRows){
    	//
    	//Orders => Table için ("User_Email) alan ve bana o eklediği insan için bir ("Order_Id") dondüren fonksiyon
    	//
    //}
    Item_Names = []
    Item_Q = []
    for(var i = 0; i < cartRows.length; i++){
    	//
    	//Orders_ElectronicDevice => Table için ("Order_ID", "Product Name", "Quantity") Kabul eden fonksiyon
    	//
    	var cartRow = cartRows[i]
    	
    	var product_name_element = cartRow.getElementsByClassName('product_name')[0]
    	var quantity_element = cartRow.getElementsByClassName('qt')[0]
    	
    	var product_name = product_name_element.innerText
    	var quantity = parseFloat(quantity_element.innerText)
    	Item_Names.push(product_name)
    	Item_Q.push(quantity)
    }
    //console.log(Item_Names, Item_Q)
    
    var xhr = new XMLHttpRequest();
    var url = "placeorder";
    xhr.open("POST", url, true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    
    var data_about = JSON.stringify({ "mail": user_name, "list_names": Item_Names, "list_q": Item_Q });
    var params = 'mail='+user_name+'&list_names='+Item_Names+'&list_q='+Item_Q;
    console.log(data_about);
    xhr.send(params);
  });
});